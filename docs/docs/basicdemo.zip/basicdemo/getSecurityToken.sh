#!/bin/sh

docker-compose run edgex-proxy --useradd=tibuser --group=admin
